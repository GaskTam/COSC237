public abstract class Item{
  private int id, numberOfCopies;
  private String title;
  
  public Item(int iD, String iTitle, int numCopy){
    id = iD >= 0 ? iD:0;
    title = iTitle;
    numberOfCopies = numCopy >= 0 ? numCopy:0;
   
  }
    public int getId(){
      return id;
  } 
    public void setId(int iD){
      id = iD >= 0 ? iD:0;
    }
    
    public String getTitle(){
      return title;
    }
    public void setTitle(String iTitle){
      title = iTitle;
    }
    public int getNumCopy(){
      return numberOfCopies;
    }
    public void setNumCopy(int numCopy){
       numberOfCopies = numCopy >= 0 ? numCopy:0;
    }
    
    public void checkIn(){
      numberOfCopies++;
    }
    public void checkOut(){
      numberOfCopies--;
    }
    public void addItem(int copies){
      numberOfCopies += copies;
    }
   public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Item item = (Item) obj;
        return id == item.id;
    }
      public String toString() {
        return "ID: " + id + ", Title: " + title + ", Copies: " + numberOfCopies;
    }
    public abstract void print();
}