abstract class MediaItem extends Item {
    private int runtime;

    public MediaItem(int id, String title, int numberOfCopies, int runtime) {
        super(id, title, numberOfCopies);
        this.runtime = runtime;
    }

    public int getRuntime() {
        return runtime;
    }

    public void setRuntime(int runtime) {
      runtime = runtime;
    }
    
    public String toString() {
        return super.toString() + ", Runtime: " + runtime + " minutes";
    }
}
