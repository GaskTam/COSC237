class JournalPaper extends WrittenItem {
    private int yearPublished;

    public JournalPaper(int id, String title, int numberOfCopies, String author, int yearPub) {
        super(id, title, numberOfCopies, author);
        yearPublished = yearPub;
    }

    public int getYearPublished() {
        return yearPublished;
    }

    public void setYearPublished(int yearPublished) {
      yearPublished = yearPublished;
    }

    public String toString() {
        return super.toString() + ", Year Published: " + yearPublished;
    }

    public void print() {
        System.out.println("Journal Paper Details: " + toString());
    }
}