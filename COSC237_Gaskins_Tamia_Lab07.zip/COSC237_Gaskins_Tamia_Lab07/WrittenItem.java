public abstract class WrittenItem extends Item {
    private String author;

    public WrittenItem(int id, String title, int numberOfCopies, String iAuthor) {
        super(id, title, numberOfCopies);
        author = iAuthor;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String iAuthor) {
        author = iAuthor;
    }
    public String toString() {
        return super.toString() + ", Author: " + author;
    }
}
