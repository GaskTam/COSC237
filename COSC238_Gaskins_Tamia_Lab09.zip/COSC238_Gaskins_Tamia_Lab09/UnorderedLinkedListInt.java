import java.util.*;
public class UnorderedLinkedListInt extends LinkedListIntClass {
    public boolean search(int searchItem) {
        LinkedListNode current = first;
        while (current != null) {
            if (current.info == searchItem) return true;
            current = current.link;
        }
        return false;
    }

    public void insertFirst(int newItem) {
        LinkedListNode newNode = new LinkedListNode(newItem, first);
        first = newNode;
        if (last == null) last = newNode;
        count++;
    }

    public void insertLast(int newItem) {
        LinkedListNode newNode = new LinkedListNode(newItem, null);
        if (first == null) {
            first = newNode;
            last = newNode;
        } else {
            last.link = newNode;
            last = newNode;
        }
        count++;
    }

    public void deleteNode(int deleteItem) {
        if (first == null) return;

        if (first.info == deleteItem) {
            first = first.link;
            if (first == null) last = null;
            count--;
            return;
        }

        LinkedListNode current = first;
        LinkedListNode previous = null;
        while (current != null && current.info != deleteItem) {
            previous = current;
            current = current.link;
        }

        if (current != null) {
            previous.link = current.link;
            if (current == last) last = previous;
            count--;
        }
    }

    public int findSum() {
        int sum = 0;
        LinkedListNode current = first;
        while (current != null) {
            sum += current.info;
            current = current.link;
        }
        return sum;
    }
    public int findMin() {
        if (first == null) throw new NoSuchElementException("The list is empty.");
        int min = first.info;
        LinkedListNode current = first.link;
        while (current != null) {
            if (current.info < min) min = current.info;
            current = current.link;
        }
        return min;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("[");
        LinkedListNode current = first;
        while (current != null) {
            sb.append(current.info);
            if (current.link != null) sb.append(", ");
            current = current.link;
        }
        sb.append("]");
        return sb.toString();
    }
}