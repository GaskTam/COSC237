import java.util.*;
import java.util.NoSuchElementException;

public abstract class LinkedListIntClass implements LinkedListIntADT {
    protected class LinkedListNode {
        public int info;
        public LinkedListNode link;

        public LinkedListNode() {
            info = 0;
            link = null;
        }

        public LinkedListNode(int elem, LinkedListNode ptr) {
            info = elem;
            link = ptr;
        }

        public Object clone() {
            LinkedListNode copy = null;
            try {
                copy = (LinkedListNode) super.clone();
            } catch (CloneNotSupportedException e) {
                return null;
            }
            return copy;
        }

        public String toString() {
            return Integer.toString(info);
        }
    }

    public class LinkedListIterator {
        protected LinkedListNode current; 
        protected LinkedListNode previous; 
  
        public LinkedListIterator() {
            current = first;
            previous = null;
        }

 
        public void reset() {
            current = first;
            previous = null;
        }

        public int next() {
            if (!hasNext()) throw new NoSuchElementException();
            LinkedListNode temp = current;
            previous = current;
            current = current.link;
            return temp.info;
        }

        public boolean hasNext() {
            return (current != null);
        }


        public void remove() {
            if (current == null) throw new NoSuchElementException();
            if (current == first) {
                first = first.link;
                current = first;
                previous = null;
                if (first == null) last = null;
            } else {
                previous.link = current.link;
                if (current == last) {
                    last = first;
                    while (last.link != null) last = last.link;
                }
                current = current.link;
            }
            count--;
        }

        public String toString() {
            return current.info.toString();
        }
    }

    protected LinkedListNode first; 
    protected LinkedListNode last;
    protected int count;           

    // Default constructor
    public LinkedListIntClass() {
        first = null;
        last = null;
        count = 0;
    }

    public boolean isEmptyList() {
        return (first == null);
    }

    public void initializeList() {
        first = null;
        last = null;
        count = 0;
    }

    public void print() {
        LinkedListNode current; 
        current = first;
        while (current != null) { 
            System.out.print(current.info + " ");
            current = current.link;
        }
        System.out.println();
    }

    public int length() {
        return count;
    }

    public int front() {
        return first.info;
    }

    public int back() {
        return last.info;
    }

    public Object clone() {
        LinkedListIntClass copy = null;
        try {
            copy = (LinkedListIntClass) super.clone();
        } catch (CloneNotSupportedException e) {
            return null;
        }

        if (first != null) {
   
            copy.first = (LinkedListNode) first.clone();
            copy.last = copy.first;
            LinkedListNode current;
            if (first != null)
                current = first.link;
            else
                current = null;
            while (current != null) {
                copy.last.link = (LinkedListNode) current.clone();
                copy.last = copy.last.link;
                current = current.link;
            }
        }
        return copy;
    }

    public abstract boolean search(int searchItem);

    public abstract void insertFirst(int newItem);

    public abstract void insertLast(int newItem);

    public abstract void deleteNode(int deleteItem);
}