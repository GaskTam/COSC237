import java.util.ArrayList;

public class Lab8_4 {
    public static void main(String[] args) {
        ArrayList<Integer> list = new ArrayList<Integer>();
        list.add(2);
        list.add(2);
        list.add(2);
        list.add(5);
        list.add(5);
        list.add(8);
        list.add(9);
        list.add(9);

        System.out.println("The original list is: ");
        print(list);

        System.out.println("The list after method call is: ");
        removeDuplicates(list);
        print(list);
    }

    public static void removeDuplicates(ArrayList<Integer> list) {
        if (list == null || list.size() == 0) {
            return;
        }

        int index = 0;
        for (int i = 1; i < list.size(); i++) {
            if (!list.get(index).equals(list.get(i))) {
                index++;
                list.set(index, list.get(i));
            }
        }

        for (int i = list.size() - 1; i > index; i--) {
            list.remove(i);
        }
    }

    public static void print(ArrayList<Integer> someList) {
        for (Integer i : someList) {
            System.out.print(i + " ");
        }
        System.out.println();
    }
}
