public abstract class CircularShape implements Shape3D {
  private double radius;
  
  public CircularShape() {
    radius = 0;
  }
  public CircularShape(double r) {
    radius = r >= 0 ? r:0;
  }
  public double getDiameter() {
    return 2* radius;
  }
  public double getRadius() {
    return radius;
  }
  public double getCrossSectionArea() {
    return Math.PI * Math.pow(radius, 2);
  }
  public double getCrossSectionPerimeter() {
    return 2 * Math.PI * radius;
  }
  public abstract double getArea();
  
  public abstract double getVolume();
  
  public abstract String toString();
  
  public abstract boolean equals(Object obj);

   public double calculateRadiusFromCircumference(double circumference) {
        return circumference / (2 * Math.PI);
    }
    
    public double calculateRadiusFromDiameter(double diameter) {
        return diameter / 2;
    }
}
