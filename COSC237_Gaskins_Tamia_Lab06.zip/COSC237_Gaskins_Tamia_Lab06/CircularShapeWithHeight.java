public abstract class CircularShapeWithHeight extends CircularShape {
    private double height;

    public CircularShapeWithHeight() {
        super();
        height = 0;
    }

    public CircularShapeWithHeight(double radius, double height) {
        super(radius);
        this.height = height >= 0 ? height : 0;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height >= 0 ? height : 0;
    }


    public abstract double getArea();

    public abstract double getVolume();

    public abstract String toString();

    public abstract boolean equals(Object obj);

    public double calculateRadiusFromCircumference(double circumference) {
        return circumference / (2 * Math.PI);
    }

    public double calculateRadiusFromDiameter(double diameter) {
        return diameter / 2;
    }
}