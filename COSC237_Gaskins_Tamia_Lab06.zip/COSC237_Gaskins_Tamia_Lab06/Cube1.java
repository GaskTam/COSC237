public class Cube1 extends RectangularPrism {
    private double sides;

    public Cube1() {
        super(0, 0, 0);
        sides = 0;
    }

    public Cube1(double size) {
        super(size, size, size);
        this.sides = size;
    }

    public double getCubeSide() {
        return sides;
    }

    public void setCubeSide(double size) {
        if (size >= 0) {
            sides = size;
            setLength(size);
            setWidth(size);
            setHeight(size);
        }
    }

    public String toString() {
        return "For this cube, all sides = " + sides + ". ";
    }

    public void print() {
        System.out.print("For this cube, all sides = " + sides + ". ");
        System.out.println("Area = " + getArea() + ". Volume = " + getVolume());
    }
    
    
    public boolean equals(Object obj){
    if (! (obj instanceof Cube1) ) return false;
    Cube1 other = (Cube1)obj;
    return super.equals(other);
  }
}
