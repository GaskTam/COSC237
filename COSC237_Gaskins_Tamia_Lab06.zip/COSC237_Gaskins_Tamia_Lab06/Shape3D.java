public interface Shape3D{
public double getArea();
public double getVolume();
public String toString();
public boolean equals(Object obj);
}
