public class Sphere1 implements Shape3D {
  private double radius;
  
  public Sphere1(){
    radius = 0;
  }
  public Sphere1(double r) {
    radius = r >=0  ? r:0;
  }
  public double getRadius() {
    return radius;
  }
  public double getArea() {
    return 4 * Math.PI * Math.pow(radius, 2);
  }
  public double getVolume() {
    return 4.0 * Math.PI * Math.pow(radius, 3) / 3.0;
  }
  public String toString() {
    return "The radius of this sphere = "+ getRadius();
  }
  
  public boolean equals(Sphere1 obj) {
    if (obj instanceof Sphere1) {
      Sphere1 otherSphere1 = (Sphere1) obj;
      return radius == otherSphere1.radius;
    }
    else 
      return false;
  }
}
