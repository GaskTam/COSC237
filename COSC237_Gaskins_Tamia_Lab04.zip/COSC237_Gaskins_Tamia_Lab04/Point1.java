public class Point1 {
    int x, y;

    public Point1() {
        x = 0;
        y = 0;
    }

    public Point1(int iX, int iY) {
        x = iX >= 0 ? iX : 0;
        y = iY >= 0 ? iY : 0;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public void setX(int iX) {
        x = iX >= 0 ? iX : 0;
    }

    public void setY(int iY) {
        y = iY >= 0 ? iY : 0;
    }

    public void set(int iX, int iY) {
        setX(iX);
        setY(iY);
    }

    public String toString() {
        return x + "," + y;
  
    public boolean equals(Object obj) {
        if (obj instanceof Point1) {
            Point1 other = (Point1) obj;
            return other.x == x && other.y == y;
        }
        return false;
    }

    public void copy(Point1 other) {
        x = other.x;
        y = other.y;
    }

    public Point1 getCopy() {
        return new Point1(x, y);
    }

    public double distanceFromOrigin() {
        return Math.sqrt(x * x + y * y);
    }

    public double distance(Point1 other) {
        int distX = x - other.x;
        int distY = y - other.y;
        return Math.sqrt(distX * distX + distY * distY);
    }
    public void translate(int distX, int distY) {
        x += distX;
        y += distY;
    }

    public boolean isHorizontal(Point1 other) {
        return y == other.y;
    }

    public boolean isVertical(Point1 other) {
        return x == other.x;
    }

    public double slope(Point1 other) {
        if (x == other.x) {
            throw new IllegalArgumentException("Undefined Slope");
        }
        return (double) (y - other.y) / (x - other.x);
    }
}
