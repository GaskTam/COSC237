import java.util.Scanner;

public class PointClient {
  public static void main(String[] args) {
    Scanner keyboard = new Scanner(System.in);
    
    Point1 p1 = new Point1();
    Point1 p2 = new Point1(7, 13);
    Point1 p3 = new Point1(7, 15);
    
    System.out.println("---After declaration, constructors invoked--- Using toString():");
    
    System.out.println("First point is " + p1);
    System.out.println("Second point is " + p2);
    System.out.println("Third point is " + p3);
    
    if (p2.isVertical(p3)) {
      System.out.println("Second point " + p2 + " lines up vertically with third point " + p3);
    } else {
      System.out.println("Second point " + p2 + " does not line up vertically with third point " + p3);
    }
    
    if (p2.isHorizontal(p3)) {
      System.out.println("Second point " + p2 + " lines up horizontally with third point " + p3);
    } else {
      System.out.println("Second point " + p2 + " does not line up horizontally with third point " + p3);
    }
    
    
    p1.setX(posInt(keyboard, "Enter the x coordinate for first point: "));
    p1.setY(posInt(keyboard, "Enter the y coordinate for first point: "));
    
    System.out.println("First point (after call to set) is " + p1);
    System.out.printf("Distance from origin for first point = %.2f\n", p1.distanceFromOrigin());
    System.out.printf("Distance from origin for second point = %.2f\n", p2.distanceFromOrigin());
    System.out.printf("Distance between first point and second point = %.2f\n", p1.distance(p2));
    
    
    p1.translate(5, 10);
    p2.translate(15, 5);
    
    System.out.println("First point (after call to translate (5, 10)) is " + p1);
    System.out.println("Second point (after call to translate (15, 5)) is " + p2);
    
    
    if (p1.equals(p2)) {
      System.out.println("Call to equals: The 2 points are equal.");
    } else {
      System.out.println("Call to equals: The 2 points are NOT equal.");
    }
    
    
    p1.copy(p2);
    System.out.println("Calls to copy and print");
    System.out.println("First point (after call to copy) is " + p1);
    System.out.println("Second point (after call to copy) is " + p2);
    
    
    if (p1.equals(p2)) {
      System.out.println("Call to equals after call to copy: The 2 points are equal.");
    } else {
      System.out.println("Call to equals after call to copy: The 2 points are NOT equal.");
    }
  }
  
  private static int posInt(Scanner keyboard, String input) {
    int result = -1;
    while (result < 0) {
      System.out.print(input);
      if (keyboard.hasNextInt()) {
        result = keyboard.nextInt();
        if (result < 0) {
          System.out.println("ERROR! Should be positive.");
        }
      } else {
        System.out.println("Not an integer! Try again!");
        keyboard.next(); 
      }
    }
    return result;
  }
}
