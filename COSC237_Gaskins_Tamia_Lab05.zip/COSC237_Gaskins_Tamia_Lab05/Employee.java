public class Employee extends Person {
    private double payRate;
    private double hoursWorked;
    private String department;

    public final int HOURS = 40;
    public final double OVERTIME = 1.5;

    // Default constructor
    public Employee() {
        super();
        payRate = 0;
        hoursWorked = 0;
        department = "Math";
    }

    // Alternate constructor
    public Employee(String iFirst, String iLast, double iPay, double iHours, String iDept) {
        super(iFirst, iLast);
        payRate = iPay >= 0 ? iPay : 0;
        hoursWorked = iHours >= 0 ? iHours : 0;
        department = iDept;
    }

    @Override
    public String toString() {
        double wages = calculatePay();
        return "The wages for " + getLName() + ", " + getFName() + " from the " + department + " department are: $" + String.format("%.2f", wages);
    }

    public void print() {
        double wages = calculatePay();
        System.out.print("The employee " + getLName() + ", " + getFName() + " from the " + department + " department worked " + hoursWorked + " hours with a pay rate of $" + String.format("%.2f", payRate) + ". The wages for this employee are $" + String.format("%.2f", wages));
    }

    public double calculatePay() {
        if (hoursWorked <= HOURS) {
            return payRate * hoursWorked;
        } else {
            double overtime = hoursWorked - HOURS;
            return (payRate * HOURS) + (payRate * OVERTIME * overtime);
        }
    }

    public void setAll(String first, String last, double rate, double hours, String dep) {
        setName(first, last);
        payRate = rate;
        hoursWorked = hours;
        department = dep;
    }

    public double getPayRate() {
        return payRate;
    }

    public double getHoursWorked() {
        return hoursWorked;
    }

    public String getDepartment() {
        return department;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Employee employee = (Employee) o;
        return Double.compare(employee.payRate, payRate) == 0 &&
                Double.compare(employee.hoursWorked, hoursWorked) == 0 &&
                department.equals(employee.department);
    }

    public Employee getCopy() {
        return new Employee(getFName(), getLName(), payRate, hoursWorked, department);
    }

    public void copy(Employee e) {
        setName(e.getFName(), e.getLName());
        payRate = e.payRate;
        hoursWorked = e.hoursWorked;
        department = e.department;
    }
}
