public class Person{
  private String firstName;
  private String lastName;
  
  public Person(){
  firstName = "Jane";
  lastName = "Smith";
  }
  public Person(String iFirst, String iLast){
    firstName = iFirst;
    lastName = iLast;
  }
  public String getFName(){
    return firstName; 
  }
  public String getLName(){
    return lastName;
  }
  public void setFName(String iFirst){
    firstName = iFirst;
  }
  public void setLName(String iLast){
    lastName = iLast;
  }
  public void setName(String iFirst, String iLast){
    firstName = iFirst;
    lastName = iLast;
  }
  public void printLastFirst(){
    System.out.println(lastName + " , " + firstName);
  
  }
  public void print(){
    System.out.println(firstName + lastName);
  }
  public String toString() {
    return firstName + " " + lastName + " ";
  }
   public boolean equals(Person obj) {
        if (obj instanceof Person) {
            Person other = (Person) obj;
            return other.firstName == firstName && other.lastName == lastName;
        }
        return false;
    }
    public void copy(Person other) {
        firstName = other.firstName;
        lastName = other.lastName;
    }

    public Person getCopy() {
        return new Person(firstName, lastName);
    } 
  
  
}