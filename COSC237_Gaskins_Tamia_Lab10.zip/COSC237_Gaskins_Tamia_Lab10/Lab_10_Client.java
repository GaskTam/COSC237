import java.util.Scanner;

public class Lab_10_Client {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        LinkedStackClass<Integer> stack = new LinkedStackClass<>();
        QueueClass<Integer> queue = new QueueClass<>(100); 
        
        System.out.print("Enter integers (999 to stop): ");
        int x = input.nextInt();
        while (x != 999) {
            stack.push(x);
            x = input.nextInt();
        }
        
        System.out.println("The original stack printed in direct order (bottom to top) is:");
        printStack(stack);

        System.out.println("The stack printed in reverse order (top to bottom) is:");
        printBackStack(stack);

        int itemCount = countItems(stack);
        System.out.println("The stack stores " + itemCount + " items.");
        
        Integer topItem = stack.peek();
        System.out.println("The top is: " + topItem);
        
        Integer secondItem = getSecond(stack);
        System.out.println("The second item (below top) is: " + secondItem);
        
        System.out.print("Enter value to be removed from stack: ");
        int valueToRemove = input.nextInt();
        removeItem(stack, valueToRemove);
        
        System.out.println("The stack after removing every occurrence of " + valueToRemove + " is:");
        printStack(stack);
        
        reverseStack(stack);
        System.out.println("Reversed the stack. The new stack printed in direct order is:");
        printStack(stack);
        
 
        for (int i = 3; i <= 30; i += 3) {
            queue.enqueue(i);
        }
        
        System.out.println("The queue is:");
        printQueue(queue);
        
        reverseQueue(queue);
        System.out.println("The reversed queue is:");
        printQueue(queue);

        input.close();
    }

    public static void printBackStack(LinkedStackClass<Integer> intStack) {
        LinkedStackClass<Integer> tempStack = new LinkedStackClass<>();
        while (!intStack.isEmptyStack()) {
            Integer topElement = intStack.peek();
            System.out.print(topElement + " ");
            tempStack.push(topElement);
            intStack.pop();
        }
        System.out.println();
        while (!tempStack.isEmptyStack()) {
            intStack.push(tempStack.peek());
            tempStack.pop();
        }
    }

    public static void printStack(LinkedStackClass<Integer> intStack) {
        LinkedStackClass<Integer> tempStack = new LinkedStackClass<>();
        while (!intStack.isEmptyStack()) {
            tempStack.push(intStack.peek());
            intStack.pop();
        }
        LinkedStackClass<Integer> finalStack = new LinkedStackClass<>();
        while (!tempStack.isEmptyStack()) {
            Integer topElement = tempStack.peek();
            System.out.print(topElement + " ");
            finalStack.push(topElement);
            tempStack.pop();
        }
        System.out.println();
        while (!finalStack.isEmptyStack()) {
            intStack.push(finalStack.peek());
            finalStack.pop();
        }
    }

    public static Integer getSecond(LinkedStackClass<Integer> intStack) {
        if (intStack.isEmptyStack()) return null;
        Integer firstItem = intStack.peek();
        intStack.pop();
        Integer secondItem = intStack.isEmptyStack() ? null : intStack.peek();
        if (secondItem != null) {
            intStack.pop();
            intStack.push(secondItem);
        }
        intStack.push(firstItem);
        return secondItem;
    }

    public static int countItems(LinkedStackClass<Integer> intStack) {
        int count = 0;
        LinkedStackClass<Integer> tempStack = new LinkedStackClass<>();
        while (!intStack.isEmptyStack()) {
            count++;
            tempStack.push(intStack.peek());
            intStack.pop();
        }
        while (!tempStack.isEmptyStack()) {
            intStack.push(tempStack.peek());
            tempStack.pop();
        }
        return count;
    }

    public static void removeItem(LinkedStackClass<Integer> intStack, Integer n) {
        LinkedStackClass<Integer> tempStack = new LinkedStackClass<>();
        while (!intStack.isEmptyStack()) {
            if (!intStack.peek().equals(n)) {
                tempStack.push(intStack.peek());
            }
            intStack.pop();
        }
        while (!tempStack.isEmptyStack()) {
            intStack.push(tempStack.peek());
            tempStack.pop();
        }
    }

    public static void reverseStack(LinkedStackClass<Integer> s) {
        QueueClass<Integer> q = new QueueClass<>();
        while (!s.isEmptyStack()) {
            q.enqueue(s.peek());
            s.pop();
        }
        while (!q.isEmptyQueue()) {
            s.push(q.front());
            q.dequeue();
        }
    }

    public static void reverseQueue(QueueClass<Integer> q) {
        LinkedStackClass<Integer> s = new LinkedStackClass<>();
        while (!q.isEmptyQueue()) {
            s.push(q.front());
            q.dequeue();
        }
        while (!s.isEmptyStack()) {
            q.enqueue(s.peek());
            s.pop();
        }
    }

    public static void printQueue(QueueClass<Integer> q) {
        QueueClass<Integer> tempQueue = new QueueClass<>(q.maxQueueSize);
        while (!q.isEmptyQueue()) {
            Integer frontElement = q.front();
            System.out.print(frontElement + " ");
            tempQueue.enqueue(frontElement);
            q.dequeue();
        }
        System.out.println();
        while (!tempQueue.isEmptyQueue()) {
            q.enqueue(tempQueue.front());
            tempQueue.dequeue();
        }
    }
}
